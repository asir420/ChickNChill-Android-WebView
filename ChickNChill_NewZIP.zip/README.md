Chick N Chill - Android WebView (Rebuild)
------------------------------------------
Your Android app for https://chicknchill-pos-pro.lovable.app/
Features:
- Splash screen
- Screen always ON
- No pull-to-refresh
- Bluetooth printer support
- GitHub Actions workflow auto-builds APK

Steps:
1. Download this ZIP.
2. Upload to GitHub (repo: ChickNChill-Android-WebView).
3. Run Actions → Build APK → Download artifact.
